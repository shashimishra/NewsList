//
//  NewsListVC.swift
//  CAB
//
//  Created by Mishra, Shashibhushan on 17/09/22.
//

import UIKit

class NewsListVC: UIViewController {

    private let refreshControl = UIRefreshControl()
    
    let newsTableView : UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        return tableView
    }()
    
    var newsListViewModel : NewsListViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        setUpNavigation()
        newsListViewModel = NewsListViewModel(dataRecieverHandler: { [weak self] in
            DispatchQueue.main.async {
                self?.newsTableView.reloadData()
//                self?.refreshControl.endRefreshing()
//                self.activityIndicatorView.stopAnimating()
            }
        })
//        addPullToRefreshToNewsView()
    }
    
    func setUpNavigation() {
     navigationItem.title = "News"
     self.navigationController?.navigationBar.barTintColor = .blue
     self.navigationController?.navigationBar.isTranslucent = false
//        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: .]
    }
    
    func setupView() {
        view?.backgroundColor = .white
        view?.addSubview(newsTableView)
        
        newsTableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true
        newsTableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        newsTableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor).isActive = true
        newsTableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor).isActive = true
        
        newsTableView.delegate = self
        newsTableView.dataSource = self
        
        newsTableView.register(NewsTableViewCell.self, forCellReuseIdentifier: "news_cell")
//        newsTableView.refreshControl = refreshControl
    }

//    @objc private func fetchData(){
//        newsListViewModel = NewsListViewModel(dataRecieverHandler: { [weak self] in
//            DispatchQueue.main.async {
//                self?.newsTableView.reloadData()
//                self?.refreshControl.endRefreshing()
////                self.activityIndicatorView.stopAnimating()
//            }
//        })
//    }
    
//    func addPullToRefreshToNewsView(){
//        refreshControl.bounds = CGRect(x: 0, y: 50, width: refreshControl.bounds.size.width, height: refreshControl.bounds.size.height)
//        refreshControl.tintColor = UIColor(red:0.25, green:0.72, blue:0.85, alpha:1.0)
//        refreshControl.attributedTitle = NSAttributedString(string: "Pull down to refresh...")
//        refreshControl.addTarget(self, action: Selector(("refreshNewsView:")), for: UIControl.Event.valueChanged)
//        view.addSubview(refreshControl)
//    }

    func refreshNewsView(refresh:UIRefreshControl) {
//        newsTableView.reloadData()
//        fetchData()
    }

}

extension NewsListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newsListViewModel?.newsModel?[0].totalResults ?? 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexpath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "news_cell") as! NewsTableViewCell
        
        cell.news = newsListViewModel?.newsModel?[0].articles?[indexPath.row]
        return cell
    }
    
    
    
    
}
