//
//  NetworkManager.swift
//  CAB
//
//  Created by Mishra, Shashibhushan on 17/09/22.
//

import Foundation

struct NetworkManager<T: Codable> {
    
    func fetchData(url: String, completionHandler: @escaping((T) -> Void) ) {
        
        guard let url = URL(string: url) else { return }
        URLSession.shared.dataTask(with: url) { (data, res, error) in
            if let safeData = data {
                do {
                    let newsList = try JSONDecoder().decode(T.self, from: safeData)
                    completionHandler(newsList)
                }
                catch DecodingError.keyNotFound(let key, let context) {
                    fatalError("Failed to decode \(res) from bundle due to missing key '\(key.stringValue)' not found – \(context.debugDescription)")
                } catch DecodingError.typeMismatch(_, let context) {
                    fatalError("Failed to decode \(res) from bundle due to type mismatch – \(context.debugDescription)")
                } catch DecodingError.valueNotFound(let type, let context) {
                    fatalError("Failed to decode \(res) from bundle due to missing \(type) value – \(context.debugDescription)")
                } catch DecodingError.dataCorrupted(_) {
                    fatalError("Failed to decode \(res) from bundle because it appears to be invalid JSON")
                } catch {
                    fatalError("Failed to decode \(res) from bundle: \(error.localizedDescription)")
                }

//                    catch {
//                    NSLog("Error\(error.localizedDescription)")
//                }
            }
        } .resume()
    
    }
    
}
