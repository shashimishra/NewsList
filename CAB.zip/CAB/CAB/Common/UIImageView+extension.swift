//
//  UIImageView+extension.swift
//  CAB
//
//  Created by Mishra, Shashibhushan on 17/09/22.
//

import UIKit

extension UIImageView {
    
    func getData(from url: URL, completion: @escaping(Data?, URLResponse?, Error?)-> ()) {
        URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
    }
    
    func downloadImage(from url:URL) {
        print("Downlod started")
        getData(from: url) { (data,response,error) in
            guard let data = data, error == nil else { return }
            print(response?.suggestedFilename ?? url.lastPathComponent)
            print("Downlod finished")
            
            DispatchQueue.main.async() { [weak self] in
                self?.image = UIImage(data: data)
            }
        }
        
    }
    
    
}
