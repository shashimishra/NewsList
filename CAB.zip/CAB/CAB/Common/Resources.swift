//
//  Resources.swift
//  CAB
//
//  Created by Mishra, Shashibhushan on 17/09/22.
//

import Foundation

enum Resource: String {
    
    case getNewsList = "https://newsapi.org/v2/top-headlines?country=us&apiKey=99aedfe4c3744ed6a98654189b52a623"
//    case getNewsList = "https://fakestoreapi.com/products"
}
