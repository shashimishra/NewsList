//
//  NewsListViewModel.swift
//  CAB
//
//  Created by Mishra, Shashibhushan on 17/09/22.
//

import Foundation


class NewsListViewModel {
    
    var newsModel : [News]?

    init(dataRecieverHandler: @escaping() ->Void) {
        NetworkManager<News>().fetchData(url: Resource.getNewsList.rawValue) { [weak self] newsList in
            self?.newsModel = [newsList]
            dataRecieverHandler()
        }
    }
    
}
