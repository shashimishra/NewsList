//
//  NewsTableViewCell.swift
//  CAB
//
//  Created by Mishra, Shashibhushan on 17/09/22.
//

import UIKit

class NewsTableViewCell: UITableViewCell {

    let horizontalStackView : UIStackView = {
        let hs = UIStackView()
        hs.translatesAutoresizingMaskIntoConstraints = false
        hs.axis = .horizontal
        hs.spacing = 4
        return hs
    }()
    
    let verticalStacklView : UIStackView = {
       let vs = UIStackView()
        vs.translatesAutoresizingMaskIntoConstraints = false
        vs.spacing = 3
        vs.axis = .vertical
        return vs
    }()
    
    let newsImageView : UIImageView = {
        let iv = UIImageView()
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        iv.layer.masksToBounds = true
        iv.layer.cornerRadius = 35
        iv.layer.borderWidth = 0.4
        iv.layer.borderColor = UIColor.lightGray.cgColor
        iv.widthAnchor.constraint(equalToConstant: 90).isActive = true
        iv.heightAnchor.constraint(equalToConstant: 60).isActive = true
        return iv
    }()
    
    let titleLabel : UILabel = {
       let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.systemFont(ofSize: 14, weight: .bold)
        return l
    }()
    
    let descLabel : UILabel = {
       let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        l.textColor = .lightGray
        return l
    }()
    
    let contentLabel : UILabel = {
       let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.systemFont(ofSize: 8, weight: .light)
        l.textAlignment = .left
        return l
    }()
    
    var news : Article? {
        didSet {
            if let safeNews = news {
                titleLabel.text = safeNews.title
                descLabel.text  = safeNews.description
                contentLabel.text = safeNews.content
                let url = URL(string: safeNews.urlToImage ?? "")
                if let imageUrl = url {
                    newsImageView.downloadImage(from: imageUrl)
                }
            }
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupViews()  {
        let cardView = makeCardView()
        addSubview(cardView)
        cardView.topAnchor.constraint(equalTo: self.topAnchor, constant: 4).isActive            = true
        cardView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 4).isActive    = true
        cardView.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -4).isActive = true
        cardView.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -4).isActive     = true
       
        cardView.addSubview(horizontalStackView)
        horizontalStackView.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 5).isActive           = true
        horizontalStackView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 5).isActive   = true
        horizontalStackView.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -5).isActive = true
        horizontalStackView.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -5).isActive    = true
        horizontalStackView.addArrangedSubview(newsImageView)
        
        horizontalStackView.addArrangedSubview(newsImageView)
        
        verticalStacklView.addArrangedSubview(titleLabel)
        verticalStacklView.addArrangedSubview(descLabel)
        verticalStacklView.addArrangedSubview(contentLabel)
        
        horizontalStackView.addArrangedSubview(verticalStacklView)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}

extension NewsTableViewCell {
    
    func makeCardView() -> UIView {
        let cardView = UIView()
        cardView.translatesAutoresizingMaskIntoConstraints = false
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 10.0
        cardView.layer.shadowColor = UIColor.lightGray.cgColor
        cardView.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        cardView.layer.shadowRadius = 6.0
        cardView.layer.shadowOpacity = 0.7
        return cardView
    }
}
